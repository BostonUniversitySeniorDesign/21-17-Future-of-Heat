                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1374215
Nuclear Power Plant - wargame terrain building by GarageBay9 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is a building set of a nuclear power plant, for tabletop wargaming scenery use.  It is not any specific real-life reactor complex.  It includes a cooling tower, reactor facility, and administrative offices / auxiliary building.

This model set is intended to be painted for completion.  For best results, you can also add fine details beyond what is possible with 3D printing, using modeling and hobby supplies, before final painting.  Thin copper wire, fine styrene stock in various shapes, filler compound, and all kinds of other options can enhance the finished pieces.

Originally designed for 6mm BattleTech (1/285), using 1 hex = 1.75" (1.5in with .125" gutter, similar to HeroScape terrain). Can be scaled to fit other game scales.

If working in mm in your slicing software, scale the .STL by 25.4.

# Print Settings

Printer: Rostock Max
Rafts: Doesn't Matter
Supports: No
Resolution: .15mm / layer
Infill: 2-15% (estimated)

Notes: 
Multiply scale by 25.4 if working in mm.

Designed for single-extruder .5mm ABS filament. Object is manifold with minimized undercuts and should print successfully with any thermoplastic filament extrusion, powder substrate (3DSystems / zCorp), or similar additive process.

Not suitable for small children.

This model set is an artistic work that may be altered at the creator's discretion and files are subject to small or large changes without notice.