                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1237576
Big Hotel - Project..  by _sOnGoKu_ is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

My next project is a hotel. I have a few days working on editing files, but already beginning to see results, so I'll put the pieces as you go running.

The model obtained in this building this thing:
http://www.thingiverse.com/thing:809091

As you can see, it has cast larger, to suit the scale that I need. I also want to put windows and sunshades on the windows. maybe some surprise more :)

Ha! and happy New Year :)

Updated 1/1/2016:
second floor & windows add
Updated 2/1/2016:
Roof add


PLEASE! do not use this or any other mine contribution to make money.
They are shared to enhance DIY. 
Thank you

you want more designs?
Join the group and check out. bring your favorite designs!
@ http://www.thingiverse.com/groups/scalemodels/things

If this thing was helpful or you like the designs, please click the "like" button. in that way I will continue sharing more things.

If you print one I would love to see it in the section "i made one"
of course, all views and advice are welcomed, you can always improve design..

thanks for watching